## SECTION 1 : PROJECT TITLE
## Mortgage Loan Application Process

---
## SECTION 2 : EXECUTIVE SUMMARY / PAPER ABSTRACT
From the course, I have learnt to extract business rule from data using inductive reasoning. I have successfully enhanced the KIE home loan system using the discovered knowledge. Towards the end of the project, I have exported my project to github and IVLE system for the individual project submission. 

---
## SECTION 3 : CREDITS / PROJECT CONTRIBUTION

| Official Full Name  | Student ID (MTech Applicable)  | Work Items (Who Did What) | Email (Optional) |
| :------------ |:---------------:| :-----| :-----|
| Lee Boon Kien | A0195175W | Extracted business rule, enhanced KIE home loan system Export, enhanced KIE system| e0384806@nus.edu.sg |
---
## SECTION 4 : VIDEO OF SYSTEM MODELLING & USE CASE DEMO

NA

---
## SECTION 5 : USER GUIDE

NA

---
## SECTION 6 : PROJECT REPORT / PAPER

NA

---
## SECTION 7 : MISCELLANEOUS

NA

---